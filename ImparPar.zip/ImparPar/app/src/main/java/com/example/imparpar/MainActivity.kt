package com.example.imparpar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    var resultado = 0
    private var score = 0
    lateinit var txtResultado: TextView
    lateinit var btnNovoJogo: Button
    lateinit var txtOpcional: TextView
    lateinit var btnOpcional: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtResultado = findViewById(R.id.txtResultado)
        btnNovoJogo = findViewById(R.id.btnNovoJogo)
        txtOpcional = findViewById(R.id.txtOpcional)
        btnOpcional = findViewById(R.id.btnOpcional)
        novoJogo()
    }

    private fun novoJogo(){
        txtResultado.text = "Impar ou Par?"
        resultado = Random.nextInt(0,10)
        btnNovoJogo.visibility = View.INVISIBLE
    }

    fun novoJogo(view: View){
        novoJogo()
    }

    fun resetar(view: View){
        score = 0
        title = "Score resetado!"
    }

    fun jogada(view: View){
        if(resultado % 2 == view.tag.toString().toInt()){
            if(btnNovoJogo.visibility == View.INVISIBLE){
                score++
                Toast.makeText(this, "GANHOU", Toast.LENGTH_SHORT)
                getPreferences(MODE_PRIVATE).edit().putInt("SCORE", score).commit()
            }
        }else{
            score--
        }
        if(score < 0)
            score = 0
        if(score == 0){
            txtResultado.text = "GAME OVER!"
        }
        title = "Score: $score"
        txtResultado.text = "$resultado"
        btnNovoJogo.visibility = View.VISIBLE
        btnOpcional.visibility = View.VISIBLE
        txtOpcional.visibility = View.VISIBLE

    }
}